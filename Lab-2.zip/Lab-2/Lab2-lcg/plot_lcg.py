import pandas as pd
import matplotlib.pyplot as plt

# Load CSV file
data = pd.read_csv("lcg_results.csv")

# If your column is named avg_time_us, rename for convenience
if "avg_time_us" in data.columns:
    data = data.rename(columns={"avg_time_us": "time_us"})

# ===== Linear plot =====
plt.figure()
plt.plot(data["n"], data["time_us"], marker="o")
plt.xlabel("Input size (n)")
plt.ylabel("Execution time (microseconds)")
plt.title("Empirical Analysis of Linear Congruential Generator (LCG)")
plt.grid(True)

# Save figure
plt.savefig("lcg_plot_linear.png", dpi=300)

plt.show()
