#include <iostream>
#include <fstream>
#include <chrono>
#include <cstdint>

using namespace std;
using namespace std::chrono;

// LCG: X_{k+1} = (a * X_k + c) mod m
static inline uint64_t lcg_step(uint64_t x, uint64_t a, uint64_t c, uint64_t m) {
    return (a * x + c) % m;
}

// Generate n numbers, return last value so work isn't optimized away
uint64_t lcg_generate(uint64_t n, uint64_t seed, uint64_t a, uint64_t c, uint64_t m) {
    uint64_t x = seed;
    for (uint64_t i = 0; i < n; i++) {
        x = lcg_step(x, a, c, m);
    }
    return x;
}

int main() {
    // Common LCG parameters (you can also use your textbook values)
    uint64_t seed = 123456789ULL;
    uint64_t m    = (1ULL << 32);      // 2^32
    uint64_t a    = 1664525ULL;
    uint64_t c    = 1013904223ULL;

    // Larger n values (so time is measurable)
    uint64_t tests[] = {
        100000ULL,
        200000ULL,
        500000ULL,
        1000000ULL,
        2000000ULL,
        5000000ULL,
        10000000ULL,
        20000000ULL,
        50000000ULL
    };

    // Repeat each test to reduce noise
    const int repeats = 10;

    ofstream file("lcg_results.csv");
    file << "n,time_us\n";

    cout << "n\tavg_time_us\n";

    volatile uint64_t sink = 0; // volatile prevents aggressive optimization

    for (uint64_t n : tests) {
        long long total_us = 0;

        for (int r = 0; r < repeats; r++) {
            auto start = high_resolution_clock::now();
            sink ^= lcg_generate(n, seed + r, a, c, m);
            auto end = high_resolution_clock::now();

            total_us += duration_cast<microseconds>(end - start).count();
        }

        double avg_us = (double)total_us / repeats;

        cout << n << "\t" << avg_us << "\n";
        file << n << "," << avg_us << "\n";
    }

    file.close();
    return 0;
}
