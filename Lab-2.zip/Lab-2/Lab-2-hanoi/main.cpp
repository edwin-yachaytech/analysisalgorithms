#include <iostream>
#include <chrono>
#include <fstream>

using namespace std;
using namespace chrono;

long long moves_recursive = 0;

void hanoi_recursive(int n, char source, char auxiliary, char target)
{
    if (n == 1)
    {
        moves_recursive++;
        return;
    }

    hanoi_recursive(n - 1, source, target, auxiliary);
    moves_recursive++;
    hanoi_recursive(n - 1, auxiliary, source, target);
}

long long hanoi_iterative(int n)
{
    long long moves = 0;
    long long total_moves = (1LL << n) - 1;

    for(long long i = 0; i < total_moves; i++)
        moves++;

    return moves;
}

int main()
{
    ofstream file("hanoi_results.csv");
    file << "n,recursive_time,iterative_time\n";

    cout << "n\tRecursive(ms)\tIterative(ms)\n";

    for(int n = 1; n <= 25; n++)
    {
        moves_recursive = 0;

        auto start1 = high_resolution_clock::now();
        hanoi_recursive(n, 'A', 'B', 'C');
        auto end1 = high_resolution_clock::now();

        auto recursive_time =
            duration_cast<milliseconds>(end1 - start1).count();

        auto start2 = high_resolution_clock::now();
        hanoi_iterative(n);
        auto end2 = high_resolution_clock::now();

        auto iterative_time =
            duration_cast<milliseconds>(end2 - start2).count();

        cout << n << "\t"
             << recursive_time << "\t\t"
             << iterative_time << endl;

        file << n << ","
             << recursive_time << ","
             << iterative_time << "\n";
    }

    file.close();
    return 0;
}
