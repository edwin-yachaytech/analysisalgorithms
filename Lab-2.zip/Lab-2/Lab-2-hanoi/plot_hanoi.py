import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv("hanoi_results.csv")

plt.figure()
plt.plot(data["n"], data["recursive_time"], label="Recursive")
plt.plot(data["n"], data["iterative_time"], label="Iterative")

plt.xlabel("Number of disks (n)")
plt.ylabel("Execution time (ms)")
plt.title("Tower of Hanoi Empirical Analysis")
plt.yscale("log")  # ← clave para confirmar O(2^n)
plt.legend()
plt.grid()

plt.show()
